import serial
import time
import sys


class Sender:
    def __init__(self, params, serial_port, debug: bool):
        self.param = params
        self.serial_port = serial_port
        self.debug = debug

    def send_button_values(self):
        button_out_states = {}
        # 1. get configured button controllers
        for unit_index, unit_data in self.param.get_config().items():
            for controller_index, controller_data in unit_data.items():
                if 0 <= controller_index <= 5:
                    path = controller_data['path']
                    values_by_path = self.param.get_values_by_path()

                    if path in values_by_path.keys():
                        value = values_by_path[path]
                        # Create Dict entry if it doesn't exist
                        if unit_index not in button_out_states.keys():
                            button_out_states[unit_index] = {}

                        button_out_states[unit_index][controller_index] = value
        command_values = []
        for pot_unit, unit_data in button_out_states.items():
            start_condition = 240 + int(pot_unit)
            command_values.append(start_condition)
            command_values.append(229)  # 0xE5 = SET BUTTON VALUES (DECIMAL 229)
            for btn_index in range(6):
                if btn_index in unit_data.keys() and unit_data[btn_index] is not None:
                    if self.debug:
                        print("SERIAL VALUE SENDING: ", btn_index, unit_data, unit_data[btn_index])
                    value = self.format_value(btn_index, unit_data[btn_index])
                else:
                    value = 15  # 0x0F - Don't Set Button
                command_values.append(value)
        if self.debug:
            print("Sending Command Button Values: ", command_values)
        self.serial_port.write(bytes(command_values))

    @staticmethod
    def format_value(btn_index: int, raw_value: float) -> int:
        formatted_value = 0
        if btn_index != 1:
            if raw_value > 0:
                formatted_value = 1
        else:
            if raw_value == 0:
                formatted_value = 0
            else:
                formatted_value = round(1. / raw_value)
        formatted_value = int(formatted_value)
        return formatted_value


"""
    0xE5 = SET BUTTON VALUES  followed by 6 data bytes
            DataBytes 6x
                Button Index (0x00 - 0x05)
                Button State:
                    0x01 - 0x04 Button Value
                    0x0F - Don't Set Button
"""
